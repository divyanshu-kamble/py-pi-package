from demo.__init__ import *

def wel(name):
    print("welcome to the main file {}".format(name))
