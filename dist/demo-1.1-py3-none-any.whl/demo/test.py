from demo.__init__ import *

def wel(name):
    print("welcome to the main file {} , this is version 1.1".format(name))
