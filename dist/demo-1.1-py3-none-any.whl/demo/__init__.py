def start():
    print("this is an init file")